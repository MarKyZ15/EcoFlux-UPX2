package com.exemplo.ecoflux.controller;

import com.exemplo.ecoflux.repository.RegistroDescarteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @Autowired
    private RegistroDescarteRepository repository;

    @GetMapping("/dashboard")
    public String exibirDashboard(Model model) {
        // Busca a soma de todos os pesos registrados no banco de dados
        Double pesoTotal = repository.calcularPesoTotal();

        // Regra de negócio simples para engajamento dos moradores
        // Exemplo: cada 10kg de material reciclado poupa 1 árvore teórica
        Double arvoresPoupadas = pesoTotal / 10.0;

        // Passa os valores calculados para o HTML (Front-end)
        model.addAttribute("pesoTotal", String.format("%.2f", pesoTotal));
        model.addAttribute("arvoresPoupadas", Math.round(arvoresPoupadas));

        // Retorna o nome do arquivo HTML (dashboard.html) que vamos criar na pasta templates
        return "dashboard";
    }
}