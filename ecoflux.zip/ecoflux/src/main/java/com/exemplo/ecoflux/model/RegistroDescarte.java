package com.exemplo.ecoflux.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "registro_descarte")
public class RegistroDescarte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "peso_kg")
    private Double pesoKg;

    @Column(name = "volume_porcentagem")
    private Integer volumePorcentagem;

    @Column(name = "data_hora")
    private LocalDateTime dataHora;

    // Construtor padrão necessário para o banco de dados
    public RegistroDescarte() {}

    // Getters e Setters (Para o Java conseguir ler e escrever os dados)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Double getPesoKg() { return pesoKg; }
    public void setPesoKg(Double pesoKg) { this.pesoKg = pesoKg; }
    public Integer getVolumePorcentagem() { return volumePorcentagem; }
    public void setVolumePorcentagem(Integer volumePorcentagem) { this.volumePorcentagem = volumePorcentagem; }
    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }
}