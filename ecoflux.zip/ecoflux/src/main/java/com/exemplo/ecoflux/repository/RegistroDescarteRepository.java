package com.exemplo.ecoflux.repository;

import com.exemplo.ecoflux.model.RegistroDescarte;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RegistroDescarteRepository extends JpaRepository<RegistroDescarte, Long> {

    // Essa query vai somar todo o peso reciclado para a gente mostrar no painel do elevador
    @Query("SELECT COALESCE(SUM(r.pesoKg), 0) FROM RegistroDescarte r")
    Double calcularPesoTotal();
}