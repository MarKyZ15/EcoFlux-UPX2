package com.exemplo.ecoflux.service;

import com.exemplo.ecoflux.model.RegistroDescarte;
import com.exemplo.ecoflux.repository.RegistroDescarteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.time.LocalDateTime;
import java.util.Random;

@Component
@EnableScheduling
public class SimuladorLixeiraService {

    @Autowired
    private RegistroDescarteRepository repository;

    // O Java vai simular um novo descarte a cada 10 segundos para testarmos o painel
    @Scheduled(fixedRate = 2000)
    public void simularDescarte() {
        Random random = new Random();

        RegistroDescarte novoDado = new RegistroDescarte();
        // Simula um peso entre 500g e 5kg por descarte
        novoDado.setPesoKg(0.5 + (5.0 - 0.5) * random.nextDouble());
        // Simula a lixeira enchendo de 0% a 100%
        novoDado.setVolumePorcentagem(random.nextInt(100));
        novoDado.setDataHora(LocalDateTime.now());

        repository.save(novoDado);
        System.out.println(">>> EcoFlux: Novo descarte simulado com sucesso no Banco de Dados!");
    }
}