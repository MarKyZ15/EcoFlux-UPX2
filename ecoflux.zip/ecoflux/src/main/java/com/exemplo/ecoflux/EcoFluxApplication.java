package com.exemplo.ecoflux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling // Ativa o simulador de dados automático que criamos
public class EcoFluxApplication {
    public static void main(String[] args) {
        SpringApplication.run(EcoFluxApplication.class, args);
    }
}